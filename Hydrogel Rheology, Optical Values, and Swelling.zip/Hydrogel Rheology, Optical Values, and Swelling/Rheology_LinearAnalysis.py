#===========================================================================
#===========================================================================
#=========================================================================== Import required packages
import pandas as pd
import statistics as stat
import matplotlib.pyplot as plt

#===========================================================================
#===========================================================================
#=========================================================================== Call excel files and desired sheets
Sample1_60_1_15L = pd.read_excel('10_wt_60_1_15linear.xlsx', sheet_name = 'DFS1_S')
Sample2_60_1_15L = pd.read_excel('10_wt_60_1_15linear.xlsx', sheet_name = 'DFS2_S')
Sample3_60_1_15L = pd.read_excel('10_wt_60_1_15linear.xlsx', sheet_name = 'DFS3_S')
Sample4_60_1_15L = pd.read_excel('10_wt_60_1_15linear.xlsx', sheet_name = 'DFS4_S')
Sample5_60_1_15L = pd.read_excel('10_wt_60_1_15linear.xlsx', sheet_name = 'DFS5_S')
Sample6_60_1_15L = pd.read_excel('10_wt_60_1_15linear.xlsx', sheet_name = 'DFS6_S')
Sample7_60_1_15L = pd.read_excel('10_wt_60_1_15linear.xlsx', sheet_name = 'DFS7_S')
Sample8_60_1_15L = pd.read_excel('10_wt_60_1_15linear.xlsx', sheet_name = 'DFS8_S')
Sample9_60_1_15L = pd.read_excel('10_wt_60_1_15linear.xlsx', sheet_name = 'DFS9_S')
Sample10_60_1_15L = pd.read_excel('10_wt_60_1_15linear.xlsx', sheet_name = 'DFS10_S')

Sample1_15_1_15L = pd.read_excel('10_wt_15_1_15linear.xlsx', sheet_name = 'DFS1_S')
Sample2_15_1_15L = pd.read_excel('10_wt_15_1_15linear.xlsx', sheet_name = 'DFS2_S')
Sample3_15_1_15L = pd.read_excel('10_wt_15_1_15linear.xlsx', sheet_name = 'DFS3_S')
Sample4_15_1_15L = pd.read_excel('10_wt_15_1_15linear.xlsx', sheet_name = 'DFS4_S')
Sample5_15_1_15L = pd.read_excel('10_wt_15_1_15linear.xlsx', sheet_name = 'DFS5_S')
Sample6_15_1_15L = pd.read_excel('10_wt_15_1_15linear.xlsx', sheet_name = 'DFS6_S')
Sample7_15_1_15L = pd.read_excel('10_wt_15_1_15linear.xlsx', sheet_name = 'DFS7_S')
Sample8_15_1_15L = pd.read_excel('10_wt_15_1_15linear.xlsx', sheet_name = 'DFS8_S')
Sample9_15_1_15L = pd.read_excel('10_wt_15_1_15linear.xlsx', sheet_name = 'DFS9_S')
Sample10_15_1_15L = pd.read_excel('10_wt_15_1_15linear.xlsx', sheet_name = 'DFS10_S')

#===========================================================================
#===========================================================================
#=========================================================================== Call frequency values into variables
x1_freq_60_1 = (Sample1_60_1_15L['Frequency (Hz)'])
x2_freq_60_1 = (Sample2_60_1_15L['Frequency (Hz)'])
x3_freq_60_1 = (Sample3_60_1_15L['Frequency (Hz)'])
x4_freq_60_1 = (Sample4_60_1_15L['Frequency (Hz)'])
x5_freq_60_1 = (Sample5_60_1_15L['Frequency (Hz)'])
x6_freq_60_1 = (Sample6_60_1_15L['Frequency (Hz)'])
x7_freq_60_1 = (Sample7_60_1_15L['Frequency (Hz)'])
x8_freq_60_1 = (Sample8_60_1_15L['Frequency (Hz)'])
x9_freq_60_1 = (Sample9_60_1_15L['Frequency (Hz)'])
x10_freq_60_1 = (Sample10_60_1_15L['Frequency (Hz)'])

x1_freq_15_1 = (Sample1_15_1_15L['Frequency (Hz)'])
x2_freq_15_1 = (Sample1_15_1_15L['Frequency (Hz)'])
x3_freq_15_1 = (Sample1_15_1_15L['Frequency (Hz)'])
x4_freq_15_1 = (Sample1_15_1_15L['Frequency (Hz)'])
x5_freq_15_1 = (Sample1_15_1_15L['Frequency (Hz)'])
x6_freq_15_1 = (Sample1_15_1_15L['Frequency (Hz)'])
x7_freq_15_1 = (Sample1_15_1_15L['Frequency (Hz)'])
x8_freq_15_1 = (Sample1_15_1_15L['Frequency (Hz)'])
x9_freq_15_1 = (Sample1_15_1_15L['Frequency (Hz)'])
x10_freq_15_1 = (Sample1_15_1_15L['Frequency (Hz)'])

#=========================================================================
x1_storage_60_1 = (Sample1_60_1_15L['G\' (Pa)'])
x2_storage_60_1 = (Sample2_60_1_15L['G\' (Pa)'])
x3_storage_60_1 = (Sample3_60_1_15L['G\' (Pa)'])
x4_storage_60_1 = (Sample4_60_1_15L['G\' (Pa)'])
x5_storage_60_1 = (Sample5_60_1_15L['G\' (Pa)'])
x6_storage_60_1 = (Sample6_60_1_15L['G\' (Pa)'])
x7_storage_60_1 = (Sample7_60_1_15L['G\' (Pa)'])
x8_storage_60_1 = (Sample8_60_1_15L['G\' (Pa)'])
x9_storage_60_1 = (Sample9_60_1_15L['G\' (Pa)'])
x10_storage_60_1 = (Sample10_60_1_15L['G\' (Pa)'])

x1_storage_15_1 = (Sample1_15_1_15L['G\' (Pa)'])
x2_storage_15_1 = (Sample2_15_1_15L['G\' (Pa)'])
x3_storage_15_1 = (Sample3_15_1_15L['G\' (Pa)'])
x4_storage_15_1 = (Sample4_15_1_15L['G\' (Pa)'])
x5_storage_15_1 = (Sample5_15_1_15L['G\' (Pa)'])
x6_storage_15_1 = (Sample6_15_1_15L['G\' (Pa)'])
x7_storage_15_1 = (Sample7_15_1_15L['G\' (Pa)'])
x8_storage_15_1 = (Sample8_15_1_15L['G\' (Pa)'])
x9_storage_15_1 = (Sample9_15_1_15L['G\' (Pa)'])
x10_storage_15_1 = (Sample10_15_1_15L['G\' (Pa)'])

#=========================================================================
x1_loss_60_1 = (Sample1_60_1_15L['G\" (Pa)'])
x2_loss_60_1 = (Sample2_60_1_15L['G\" (Pa)'])
x3_loss_60_1 = (Sample3_60_1_15L['G\" (Pa)'])
x4_loss_60_1 = (Sample4_60_1_15L['G\" (Pa)'])
x5_loss_60_1 = (Sample5_60_1_15L['G\" (Pa)'])
x6_loss_60_1 = (Sample6_60_1_15L['G\" (Pa)'])
x7_loss_60_1 = (Sample7_60_1_15L['G\" (Pa)'])
x8_loss_60_1 = (Sample8_60_1_15L['G\" (Pa)'])
x9_loss_60_1 = (Sample9_60_1_15L['G\" (Pa)'])
x10_loss_60_1 = (Sample10_60_1_15L['G\" (Pa)'])

x1_loss_15_1 = (Sample1_15_1_15L['G\" (Pa)'])
x2_loss_15_1 = (Sample2_15_1_15L['G\" (Pa)'])
x3_loss_15_1 = (Sample3_15_1_15L['G\" (Pa)'])
x4_loss_15_1 = (Sample4_15_1_15L['G\" (Pa)'])
x5_loss_15_1 = (Sample5_15_1_15L['G\" (Pa)'])
x6_loss_15_1 = (Sample6_15_1_15L['G\" (Pa)'])
x7_loss_15_1 = (Sample7_15_1_15L['G\" (Pa)'])
x8_loss_15_1 = (Sample8_15_1_15L['G\" (Pa)'])
x9_loss_15_1 = (Sample9_15_1_15L['G\" (Pa)'])
x10_loss_15_1 = (Sample10_15_1_15L['G\" (Pa)'])

#=========================================================================
x1_td_60_1 = (Sample1_60_1_15L['tan_delta'])
x2_td_60_1 = (Sample2_60_1_15L['tan_delta'])
x3_td_60_1 = (Sample3_60_1_15L['tan_delta'])
x4_td_60_1 = (Sample4_60_1_15L['tan_delta'])
x5_td_60_1 = (Sample5_60_1_15L['tan_delta'])
x6_td_60_1 = (Sample6_60_1_15L['tan_delta'])
x7_td_60_1 = (Sample7_60_1_15L['tan_delta'])
x8_td_60_1 = (Sample8_60_1_15L['tan_delta'])
x9_td_60_1 = (Sample9_60_1_15L['tan_delta'])
x10_td_60_1 = (Sample10_60_1_15L['tan_delta'])

x1_td_15_1 = (Sample1_15_1_15L['tan_delta'])
x2_td_15_1 = (Sample2_15_1_15L['tan_delta'])
x3_td_15_1 = (Sample3_15_1_15L['tan_delta'])
x4_td_15_1 = (Sample4_15_1_15L['tan_delta'])
x5_td_15_1 = (Sample5_15_1_15L['tan_delta'])
x6_td_15_1 = (Sample6_15_1_15L['tan_delta'])
x7_td_15_1 = (Sample7_15_1_15L['tan_delta'])
x8_td_15_1 = (Sample8_15_1_15L['tan_delta'])
x9_td_15_1 = (Sample9_15_1_15L['tan_delta'])
x10_td_15_1 = (Sample10_15_1_15L['tan_delta'])

#===========================================================================
#===========================================================================
#=========================================================================== Averaging values and calculating standard deviation for storage modulus
avgstorage_60 = [stat.mean(i) for i in zip(x1_storage_60_1, x2_storage_60_1, x3_storage_60_1, x4_storage_60_1, x5_storage_60_1,
                                    x6_storage_60_1, x7_storage_60_1, x8_storage_60_1, x9_storage_60_1, x10_storage_60_1)]
avgstorage_15 = [stat.mean(i) for i in zip(x1_storage_15_1, x2_storage_15_1, x3_storage_15_1, x4_storage_15_1, x5_storage_15_1,
                                       x6_storage_15_1, x7_storage_15_1, x8_storage_15_1, x9_storage_15_1, x10_storage_15_1)]

SDstorage_60 = [stat.stdev(i) for i in zip(x1_storage_60_1, x2_storage_60_1, x3_storage_60_1, x4_storage_60_1, x5_storage_60_1,
                                    x6_storage_60_1, x7_storage_60_1, x8_storage_60_1, x9_storage_60_1, x10_storage_60_1)]
SDstorage_15 = [stat.stdev(i) for i in zip(x1_storage_15_1, x2_storage_15_1, x3_storage_15_1, x4_storage_15_1, x5_storage_15_1,
                                       x6_storage_15_1, x7_storage_15_1, x8_storage_15_1, x9_storage_15_1, x10_storage_15_1)]

#==============================================================================
avgloss_60 = [stat.mean(i) for i in zip(x1_loss_60_1, x2_loss_60_1, x3_loss_60_1, x4_loss_60_1, x5_loss_60_1,
                                    x6_loss_60_1, x7_loss_60_1, x8_loss_60_1, x9_loss_60_1, x10_loss_60_1)]
avgloss_15 = [stat.mean(i) for i in zip(x1_loss_15_1, x2_loss_15_1, x3_loss_15_1, x4_loss_15_1, x5_loss_15_1,
                                       x6_loss_15_1, x7_loss_15_1, x8_loss_15_1, x9_loss_15_1, x10_loss_15_1)]

SDloss_60 = [stat.stdev(i) for i in zip(x1_loss_60_1, x2_loss_60_1, x3_loss_60_1, x4_loss_60_1, x5_loss_60_1,
                                    x6_loss_60_1, x7_loss_60_1, x8_loss_60_1, x9_loss_60_1, x10_loss_60_1)]
SDloss_15 = [stat.stdev(i) for i in zip(x1_loss_15_1, x2_loss_15_1, x3_loss_15_1, x4_loss_15_1, x5_loss_15_1,
                                       x6_loss_15_1, x7_loss_15_1, x8_loss_15_1, x9_loss_15_1, x10_loss_15_1)]

#==============================================================================
avgTD_60 = [stat.mean(i) for i in zip(x1_td_60_1, x2_td_60_1, x3_td_60_1, x4_td_60_1, x5_td_60_1,
                                    x6_td_60_1, x7_td_60_1, x8_td_60_1, x9_td_60_1, x10_td_60_1)]
avgTD_15 = [stat.mean(i) for i in zip(x1_td_15_1, x2_td_15_1, x3_td_15_1, x4_td_15_1, x5_td_15_1,
                                       x6_td_15_1, x7_td_15_1, x8_td_15_1, x9_td_15_1, x10_td_15_1)]

SDTD_60 = [stat.stdev(i) for i in zip(x1_td_60_1, x2_td_60_1, x3_td_60_1, x4_td_60_1, x5_td_60_1,
                                    x6_td_60_1, x7_td_60_1, x8_td_60_1, x9_td_60_1, x10_td_60_1)]
SDTD_15 = [stat.stdev(i) for i in zip(x1_td_15_1, x2_td_15_1, x3_td_15_1, x4_td_15_1, x5_td_15_1,
                                       x6_td_15_1, x7_td_15_1, x8_td_15_1, x9_td_15_1, x10_td_15_1)]

#===========================================================================
#===========================================================================
#=========================================================================== Plot #1 - Storage Modulus
plt.figure(1, figsize=(15,8))
plt.scatter(x1_freq_60_1, avgstorage_60, marker=".", s=100, edgecolors="black",c="black", label = "10 wt % 60-1")
SDstorage_60_error = [SDstorage_60]
plt.scatter(x2_freq_15_1, avgstorage_15, marker=".", s=100, edgecolors="green",c="green", label = "10 wt % 15-1")
SDstorage_15_error = [SDstorage_15]
plt.legend(bbox_to_anchor =(1, 1), edgecolor='black', facecolor="white", framealpha=1)
_, AB1, _=plt.errorbar(x1_freq_60_1,avgstorage_60, yerr=SDstorage_60_error, fmt='o', ecolor="black", color='black', capsize=0, uplims=True)
_, AB2, _=plt.errorbar(x1_freq_15_1,avgstorage_15, yerr=SDstorage_15_error, fmt='o', ecolor="green", color='green', capsize=0, lolims=True)
AB1[0].set_marker('_')
AB1[0].set_markersize(10)
AB2[0].set_marker('_')
AB2[0].set_markersize(10)
#X and Y Axis Modification
plt.title("Storage Modulus Average - 15 % Linear Acrylamide", size=17)
plt.xlabel('Frequency (Hz)', size = 17)
plt.ylabel('G\' (Pa)', size=17)
plt.yscale("log")
plt.ylim(1000, 100000)
plt.xscale("log")
plt.xlim(0.095, 10.75)
plt.grid(zorder=0, axis='x', which='minor', color=[0.85, 0.85, 0.85])
plt.axvline(zorder=0, linewidth=0.85, x=1, color='black', linestyle='-')
plt.tick_params(axis='x', labelsize=13)
plt.tick_params(axis='y', labelsize=13)
plt.savefig('Frequency Sweep - Storage Modulus - Linear Material.png', dpi=100)

#===========================================================================
#===========================================================================
#=========================================================================== Plot #2 - Loss Modulus
plt.figure(2, figsize=(15,8))
plt.scatter(x1_freq_60_1, avgloss_60, marker=".", s=100, edgecolors="black",c="black", label = "10 wt % 60-1")
SDloss_60_error = [SDloss_60]
plt.scatter(x2_freq_15_1, avgloss_15, marker=".", s=100, edgecolors="green",c="green", label = "10 wt % 15-1")
SDloss_15_error = [SDloss_15]
plt.legend(bbox_to_anchor =(1, 1), edgecolor='black', facecolor="white", framealpha=1)
_, AB1, _=plt.errorbar(x1_freq_60_1,avgloss_60, yerr=SDloss_60_error, fmt='o', ecolor="black", color='black', capsize=0, uplims=True)
_, AB2, _=plt.errorbar(x1_freq_15_1,avgloss_15, yerr=SDloss_15_error, fmt='o', ecolor="green", color='green', capsize=0, lolims=True)
AB1[0].set_marker('_')
AB1[0].set_markersize(10)
AB2[0].set_marker('_')
AB2[0].set_markersize(10)
#X and Y Axis Modification
plt.title("Loss Modulus Average - 15% Linear Acrylamide", size=17)
plt.xlabel('Frequency (Hz)', size = 17)
plt.ylabel('G\" (Pa)', size=17)
plt.yscale("log")
plt.ylim(10, 10000)
plt.xscale("log")
plt.xlim(0.095, 10.75)
plt.grid(zorder=0, axis='x', which='minor', color=[0.85, 0.85, 0.85])
plt.axvline(zorder=0, linewidth=0.85, x=1, color='black', linestyle='-')
plt.tick_params(axis='x', labelsize=13)
plt.tick_params(axis='y', labelsize=13)
plt.savefig('Frequency Sweep - Loss Modulus - Linear Material.png', dpi=100)

#===========================================================================
#===========================================================================
#=========================================================================== Plot #2 - Tan_Delta
plt.figure(3, figsize=(15,8))
plt.scatter(x1_freq_60_1, avgTD_60, marker=".", s=100, edgecolors="black",c="black", label = "10 wt % 60-1")
SDTD_60_error = [SDTD_60]
plt.scatter(x2_freq_15_1, avgTD_15, marker=".", s=100, edgecolors="green",c="green", label = "10 wt % 15-1")
SDTD_15_error = [SDTD_15]
plt.legend(bbox_to_anchor =(1, 1), edgecolor='black', facecolor="white", framealpha=1)
_, AB1, _=plt.errorbar(x1_freq_60_1,avgTD_60, yerr=SDTD_60_error, fmt='o', ecolor="black", color='black', capsize=0, uplims=True)
_, AB2, _=plt.errorbar(x1_freq_15_1,avgTD_15, yerr=SDTD_15_error, fmt='o', ecolor="green", color='green', capsize=0, lolims=True)
AB1[0].set_marker('_')
AB1[0].set_markersize(10)
AB2[0].set_marker('_')
AB2[0].set_markersize(10)
#X and Y Axis Modification
plt.title("Tan \u03B4 Average - 15% Linear Acrylamide", size=17)
plt.xlabel('Frequency (Hz)', size = 17)
plt.ylabel('Tan \u03B4', size=17)
plt.ylim(0.0001, 0.5)
plt.xscale("log")
plt.xlim(0.095, 10.75)
plt.grid(zorder=0, axis='x', which='minor', color=[0.85, 0.85, 0.85])
plt.axvline(zorder=0, linewidth=0.85, x=1, color='black', linestyle='-')
plt.tick_params(axis='x', labelsize=13)
plt.tick_params(axis='y', labelsize=13)
plt.savefig('Frequency Sweep - Tan \u03B4 - Linear Material.png', dpi=100)