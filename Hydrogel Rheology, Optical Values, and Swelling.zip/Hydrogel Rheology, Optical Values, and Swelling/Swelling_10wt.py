#===========================================================================
#===========================================================================
#=========================================================================== Import required packages
import pandas as pd
import matplotlib.pyplot as plt

#===========================================================================
#===========================================================================
#=========================================================================== Call excel files and desired sheets
avg60_1 = pd.read_excel('Swelling_10wt.xlsx', sheet_name = '60-1')
avg45_1 = pd.read_excel('Swelling_10wt.xlsx', sheet_name = '45-1')
avg30_1 = pd.read_excel('Swelling_10wt.xlsx', sheet_name = '30-1')
avg15_1 = pd.read_excel('Swelling_10wt.xlsx', sheet_name = '15-1')

#===========================================================================
#===========================================================================
#=========================================================================== Call time values into variables
time60_1 = (avg60_1['Time 60-1 (Days)'])
time45_1 = (avg45_1['Time 45-1 (Days)'])
time30_1 = (avg30_1['Time 30-1 (Days)'])
time15_1 = (avg15_1['Time 15-1 (Days)'])

#===========================================================================
#===========================================================================
#=========================================================================== Call volume values into variables
vol60_1 = (avg60_1['Volume 60-1'])
vol45_1 = (avg45_1['Volume 45-1'])
vol30_1 = (avg30_1['Volume 30-1'])
vol15_1 = (avg15_1['Volume 15-1'])

#===========================================================================
#===========================================================================
#=========================================================================== Call SD values into variables
SD60_1 = (avg60_1['Standard Deviation 60-1'])
SD45_1 = (avg45_1['Standard Deviation 45-1'])
SD30_1 = (avg30_1['Standard Deviation 30-1'])
SD15_1 = (avg15_1['Standard Deviation 15-1'])


#===========================================================================
#===========================================================================
#=========================================================================== Plot - Swelling
plt.figure(1, figsize=(15,8))
plt.scatter(time60_1, vol60_1, marker=".", s=100, edgecolors="black", c="black", label = "10 wt % 60-1")
SD60_error = [SD60_1]
plt.scatter(time45_1, vol45_1, marker=".", s=100, edgecolors="blue", c="blue", label = "10 wt % 45-1")
SD45_error = [SD45_1]
plt.scatter(time30_1, vol30_1, marker=".", s=100, edgecolors="red", c="red", label = "10 wt % 30-1")
SD30_error = [SD30_1]
plt.scatter(time15_1, vol15_1, marker=".", s=100, edgecolors="green", c="green", label = "10 wt % 15-1")
SD15_error = [SD15_1]
plt.legend(bbox_to_anchor = (1,1), edgecolor='black', facecolor="white", framealpha = 1)

_, AB1, _=plt.errorbar(time60_1,vol60_1, yerr=SD60_error, fmt='o', ecolor="black", color='black', capsize=0, uplims=True)
_, AB2, _=plt.errorbar(time45_1,vol45_1, yerr=SD45_error, fmt='o', ecolor="blue", color='blue', capsize=0, uplims=True)
_, AB3, _=plt.errorbar(time30_1,vol30_1, yerr=SD30_error, fmt='o', ecolor="red", color='red', capsize=0, uplims=True)
_, AB4, _=plt.errorbar(time15_1,vol15_1, yerr=SD15_error, fmt='o', ecolor="green", color='green', capsize=0, uplims=True)

AB1[0].set_marker('_')
AB1[0].set_markersize(10)
AB2[0].set_marker('_')
AB2[0].set_markersize(10)
AB3[0].set_marker('_')
AB3[0].set_markersize(10)
AB4[0].set_marker('_')
AB4[0].set_markersize(10)

#X and Y Axis Modification
plt.title("Swelling Averages", size=17)
plt.xlabel('Time (Days)', size = 17)
plt.ylabel('Volume (cm\u00b3)', size=17)
plt.ylim(20, 40)
plt.xlim(-0.5, 10)
plt.grid(zorder=0, axis='x', which='minor', color=[0.85, 0.85, 0.85])
plt.tick_params(axis='x', labelsize=13)
plt.tick_params(axis='y', labelsize=13)
plt.savefig('Swelling.png', dpi=100)