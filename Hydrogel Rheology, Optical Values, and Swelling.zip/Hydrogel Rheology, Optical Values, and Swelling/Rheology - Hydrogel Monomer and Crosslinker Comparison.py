#===========================================================================
#===========================================================================
#=========================================================================== Import required packages
import pandas as pd
import statistics as stat
import matplotlib.pyplot as plt

#===========================================================================
#===========================================================================
#=========================================================================== Call excel files and desired sheets
Sample1_5wt = pd.read_excel('5_wt_15_1.xlsx', sheet_name = 'DFS1_S')
# Sample2_5wt = pd.read_excel('5_wt_15_1.xlsx', sheet_name = 'DFS2_S')
# Sample3_5wt = pd.read_excel('5_wt_15_1.xlsx', sheet_name = 'DFS3_S')
Sample4_5wt = pd.read_excel('5_wt_15_1.xlsx', sheet_name = 'DFS4_S')
Sample5_5wt = pd.read_excel('5_wt_15_1.xlsx', sheet_name = 'DFS5_S')
Sample6_5wt = pd.read_excel('5_wt_15_1.xlsx', sheet_name = 'DFS6_S')
Sample7_5wt = pd.read_excel('5_wt_15_1.xlsx', sheet_name = 'DFS7_S')
Sample8_5wt = pd.read_excel('5_wt_15_1.xlsx', sheet_name = 'DFS8_S')
Sample9_5wt = pd.read_excel('5_wt_15_1.xlsx', sheet_name = 'DFS9_S')
Sample10_5wt = pd.read_excel('5_wt_15_1.xlsx', sheet_name = 'DFS10_S')

Sample1_7_60_wt = pd.read_excel('7_wt_60_1.xlsx', sheet_name = 'DFS1_S')
Sample2_7_60_wt = pd.read_excel('7_wt_60_1.xlsx', sheet_name = 'DFS2_S')
Sample3_7_60_wt = pd.read_excel('7_wt_60_1.xlsx', sheet_name = 'DFS3_S')
Sample4_7_60_wt = pd.read_excel('7_wt_60_1.xlsx', sheet_name = 'DFS4_S')
Sample5_7_60_wt = pd.read_excel('7_wt_60_1.xlsx', sheet_name = 'DFS5_S')
Sample6_7_60_wt = pd.read_excel('7_wt_60_1.xlsx', sheet_name = 'DFS6_S')
Sample7_7_60_wt = pd.read_excel('7_wt_60_1.xlsx', sheet_name = 'DFS7_S')
Sample8_7_60_wt = pd.read_excel('7_wt_60_1.xlsx', sheet_name = 'DFS8_S')
Sample9_7_60_wt = pd.read_excel('7_wt_60_1.xlsx', sheet_name = 'DFS9_S')
Sample10_7_60_wt = pd.read_excel('7_wt_60_1.xlsx', sheet_name = 'DFS10_S')

Sample1_7wt = pd.read_excel('7_wt_15_1.xlsx', sheet_name = 'DFS1_S')
Sample2_7wt = pd.read_excel('7_wt_15_1.xlsx', sheet_name = 'DFS2_S')
Sample3_7wt = pd.read_excel('7_wt_15_1.xlsx', sheet_name = 'DFS3_S')
Sample4_7wt = pd.read_excel('7_wt_15_1.xlsx', sheet_name = 'DFS4_S')
Sample5_7wt = pd.read_excel('7_wt_15_1.xlsx', sheet_name = 'DFS5_S')
Sample6_7wt = pd.read_excel('7_wt_15_1.xlsx', sheet_name = 'DFS6_S')
Sample7_7wt = pd.read_excel('7_wt_15_1.xlsx', sheet_name = 'DFS7_S')
Sample8_7wt = pd.read_excel('7_wt_15_1.xlsx', sheet_name = 'DFS8_S')
Sample9_7wt = pd.read_excel('7_wt_15_1.xlsx', sheet_name = 'DFS9_S')
Sample10_7wt = pd.read_excel('7_wt_15_1.xlsx', sheet_name = 'DFS10_S')

Sample1_10_60_wt = pd.read_excel('10_wt_60_1.xlsx', sheet_name = 'DFS1_S')
Sample2_10_60_wt = pd.read_excel('10_wt_60_1.xlsx', sheet_name = 'DFS2_S')
Sample3_10_60_wt = pd.read_excel('10_wt_60_1.xlsx', sheet_name = 'DFS3_S')
Sample4_10_60_wt = pd.read_excel('10_wt_60_1.xlsx', sheet_name = 'DFS4_S')
Sample5_10_60_wt = pd.read_excel('10_wt_60_1.xlsx', sheet_name = 'DFS5_S')
Sample6_10_60_wt = pd.read_excel('10_wt_60_1.xlsx', sheet_name = 'DFS6_S')
Sample7_10_60_wt = pd.read_excel('10_wt_60_1.xlsx', sheet_name = 'DFS7_S')
Sample8_10_60_wt = pd.read_excel('10_wt_60_1.xlsx', sheet_name = 'DFS8_S')
Sample9_10_60_wt = pd.read_excel('10_wt_60_1.xlsx', sheet_name = 'DFS9_S')
Sample10_10_60_wt = pd.read_excel('10_wt_60_1.xlsx', sheet_name = 'DFS10_S')

Sample1_10wt = pd.read_excel('10_wt_15_1.xlsx', sheet_name = 'DFS1_S')
Sample2_10wt = pd.read_excel('10_wt_15_1.xlsx', sheet_name = 'DFS2_S')
Sample3_10wt = pd.read_excel('10_wt_15_1.xlsx', sheet_name = 'DFS3_S')
Sample4_10wt = pd.read_excel('10_wt_15_1.xlsx', sheet_name = 'DFS4_S')
Sample5_10wt = pd.read_excel('10_wt_15_1.xlsx', sheet_name = 'DFS5_S')
Sample6_10wt = pd.read_excel('10_wt_15_1.xlsx', sheet_name = 'DFS6_S')
# Sample7_10wt = pd.read_excel('10_wt_15_1.xlsx', sheet_name = 'DFS7_S')
Sample8_10wt = pd.read_excel('10_wt_15_1.xlsx', sheet_name = 'DFS8_S')
Sample9_10wt = pd.read_excel('10_wt_15_1.xlsx', sheet_name = 'DFS9_S')
Sample10_10wt = pd.read_excel('10_wt_15_1.xlsx', sheet_name = 'DFS10_S')

Sample1_12wt = pd.read_excel('12_wt_15_1.xlsx', sheet_name = 'DFS1_S')
Sample2_12wt = pd.read_excel('12_wt_15_1.xlsx', sheet_name = 'DFS2_S')
Sample3_12wt = pd.read_excel('12_wt_15_1.xlsx', sheet_name = 'DFS3_S')
Sample4_12wt = pd.read_excel('12_wt_15_1.xlsx', sheet_name = 'DFS4_S')
Sample5_12wt = pd.read_excel('12_wt_15_1.xlsx', sheet_name = 'DFS5_S')
Sample6_12wt = pd.read_excel('12_wt_15_1.xlsx', sheet_name = 'DFS6_S')
Sample7_12wt = pd.read_excel('12_wt_15_1.xlsx', sheet_name = 'DFS7_S')
Sample8_12wt = pd.read_excel('12_wt_15_1.xlsx', sheet_name = 'DFS8_S')
Sample9_12wt = pd.read_excel('12_wt_15_1.xlsx', sheet_name = 'DFS9_S')
Sample10_12wt = pd.read_excel('12_wt_15_1.xlsx', sheet_name = 'DFS10_S')

#===========================================================================
#===========================================================================
#=========================================================================== Call frequency values into variables
x1_freq_5wt = (Sample1_5wt['Frequency (Hz)'])
# x2_freq_5wt = (Sample2_5wt['Frequency (Hz)'])
# x3_freq_5wt = (Sample3_5wt['Frequency (Hz)'])
x4_freq_5wt = (Sample4_5wt['Frequency (Hz)'])
x5_freq_5wt = (Sample5_5wt['Frequency (Hz)'])
x6_freq_5wt = (Sample6_5wt['Frequency (Hz)'])
x7_freq_5wt = (Sample7_5wt['Frequency (Hz)'])
x8_freq_5wt = (Sample8_5wt['Frequency (Hz)'])
x9_freq_5wt = (Sample9_5wt['Frequency (Hz)'])
x10_freq_5wt = (Sample10_5wt['Frequency (Hz)'])

x1_freq_7wt_60 = (Sample1_7_60_wt['Frequency (Hz)'])
x2_freq_7wt_60 = (Sample2_7_60_wt['Frequency (Hz)'])
x3_freq_7wt_60 = (Sample3_7_60_wt['Frequency (Hz)'])
x4_freq_7wt_60 = (Sample4_7_60_wt['Frequency (Hz)'])
x5_freq_7wt_60 = (Sample5_7_60_wt['Frequency (Hz)'])
x6_freq_7wt_60 = (Sample6_7_60_wt['Frequency (Hz)'])
x7_freq_7wt_60 = (Sample7_7_60_wt['Frequency (Hz)'])
x8_freq_7wt_60 = (Sample8_7_60_wt['Frequency (Hz)'])
x9_freq_7wt_60 = (Sample9_7_60_wt['Frequency (Hz)'])
x10_freq_7wt_60 = (Sample10_7_60_wt['Frequency (Hz)'])

x1_freq_7wt = (Sample1_7wt['Frequency (Hz)'])
x2_freq_7wt = (Sample2_7wt['Frequency (Hz)'])
x3_freq_7wt = (Sample3_7wt['Frequency (Hz)'])
x4_freq_7wt = (Sample4_7wt['Frequency (Hz)'])
x5_freq_7wt = (Sample5_7wt['Frequency (Hz)'])
x6_freq_7wt = (Sample6_7wt['Frequency (Hz)'])
x7_freq_7wt = (Sample7_7wt['Frequency (Hz)'])
x8_freq_7wt = (Sample8_7wt['Frequency (Hz)'])
x9_freq_7wt = (Sample9_7wt['Frequency (Hz)'])
x10_freq_7wt = (Sample10_7wt['Frequency (Hz)'])

x1_freq_10wt_60 = (Sample1_10_60_wt['Frequency (Hz)'])
x2_freq_10wt_60 = (Sample2_10_60_wt['Frequency (Hz)'])
x3_freq_10wt_60 = (Sample3_10_60_wt['Frequency (Hz)'])
x4_freq_10wt_60 = (Sample4_10_60_wt['Frequency (Hz)'])
x5_freq_10wt_60 = (Sample5_10_60_wt['Frequency (Hz)'])
x6_freq_10wt_60 = (Sample6_10_60_wt['Frequency (Hz)'])
x7_freq_10wt_60 = (Sample7_10_60_wt['Frequency (Hz)'])
x8_freq_10wt_60 = (Sample8_10_60_wt['Frequency (Hz)'])
x9_freq_10wt_60 = (Sample9_10_60_wt['Frequency (Hz)'])
x10_freq_10wt_60 = (Sample10_10_60_wt['Frequency (Hz)'])

x1_freq_10wt = (Sample1_10wt['Frequency (Hz)'])
x2_freq_10wt = (Sample2_10wt['Frequency (Hz)'])
x3_freq_10wt = (Sample3_10wt['Frequency (Hz)'])
x4_freq_10wt = (Sample4_10wt['Frequency (Hz)'])
x5_freq_10wt = (Sample5_10wt['Frequency (Hz)'])
x6_freq_10wt = (Sample6_10wt['Frequency (Hz)'])
# x7_freq_10wt = (Sample7_10wt['Frequency (Hz)'])
x8_freq_10wt = (Sample8_10wt['Frequency (Hz)'])
x9_freq_10wt = (Sample9_10wt['Frequency (Hz)'])
x10_freq_10wt = (Sample10_10wt['Frequency (Hz)'])

x1_freq_12wt = (Sample1_12wt['Frequency (Hz)'])
x2_freq_12wt = (Sample2_12wt['Frequency (Hz)'])
x3_freq_12wt = (Sample3_12wt['Frequency (Hz)'])
x4_freq_12wt = (Sample4_12wt['Frequency (Hz)'])
x5_freq_12wt = (Sample5_12wt['Frequency (Hz)'])
x6_freq_12wt = (Sample6_12wt['Frequency (Hz)'])
x7_freq_12wt = (Sample7_12wt['Frequency (Hz)'])
x8_freq_12wt = (Sample8_12wt['Frequency (Hz)'])
x9_freq_12wt = (Sample9_12wt['Frequency (Hz)'])
x10_freq_12wt = (Sample10_12wt['Frequency (Hz)'])

#===========================================================================
#===========================================================================
#=========================================================================== Call storage moduli values into variables
y1_storage_5wt = (Sample1_5wt['G\' (Pa)'])
# y2_storage_5wt = (Sample2_5wt['GI (Pa)'])
# y3_storage_5wt = (Sample3_5wt['GI (Pa)'])
y4_storage_5wt = (Sample4_5wt['G\' (Pa)'])
y5_storage_5wt = (Sample5_5wt['G\' (Pa)'])
y6_storage_5wt = (Sample6_5wt['G\' (Pa)'])
y7_storage_5wt = (Sample7_5wt['G\' (Pa)'])
y8_storage_5wt = (Sample8_5wt['G\' (Pa)'])
y9_storage_5wt = (Sample9_5wt['G\' (Pa)'])
y10_storage_5wt = (Sample10_5wt['G\' (Pa)'])

y1_storage_7wt_60 = (Sample1_7_60_wt['G\' (Pa)'])
y2_storage_7wt_60 = (Sample2_7_60_wt['G\' (Pa)'])
y3_storage_7wt_60 = (Sample3_7_60_wt['G\' (Pa)'])
y4_storage_7wt_60 = (Sample4_7_60_wt['G\' (Pa)'])
y5_storage_7wt_60 = (Sample5_7_60_wt['G\' (Pa)'])
y6_storage_7wt_60 = (Sample6_7_60_wt['G\' (Pa)'])
y7_storage_7wt_60 = (Sample7_7_60_wt['G\' (Pa)'])
y8_storage_7wt_60 = (Sample8_7_60_wt['G\' (Pa)'])
y9_storage_7wt_60 = (Sample9_7_60_wt['G\' (Pa)'])
y10_storage_7wt_60 = (Sample10_7_60_wt['G\' (Pa)'])

y1_storage_7wt = (Sample1_7wt['G\' (Pa)'])
y2_storage_7wt = (Sample2_7wt['G\' (Pa)'])
y3_storage_7wt = (Sample3_7wt['G\' (Pa)'])
y4_storage_7wt = (Sample4_7wt['G\' (Pa)'])
y5_storage_7wt = (Sample5_7wt['G\' (Pa)'])
y6_storage_7wt = (Sample6_7wt['G\' (Pa)'])
y7_storage_7wt = (Sample7_7wt['G\' (Pa)'])
y8_storage_7wt = (Sample8_7wt['G\' (Pa)'])
y9_storage_7wt = (Sample9_7wt['G\' (Pa)'])
y10_storage_7wt = (Sample10_7wt['G\' (Pa)'])

y1_storage_10wt_60 = (Sample1_10_60_wt['G\' (Pa)'])
y2_storage_10wt_60 = (Sample2_10_60_wt['G\' (Pa)'])
y3_storage_10wt_60 = (Sample3_10_60_wt['G\' (Pa)'])
y4_storage_10wt_60 = (Sample4_10_60_wt['G\' (Pa)'])
y5_storage_10wt_60 = (Sample5_10_60_wt['G\' (Pa)'])
y6_storage_10wt_60 = (Sample6_10_60_wt['G\' (Pa)'])
y7_storage_10wt_60 = (Sample7_10_60_wt['G\' (Pa)'])
y8_storage_10wt_60 = (Sample8_10_60_wt['G\' (Pa)'])
y9_storage_10wt_60 = (Sample9_10_60_wt['G\' (Pa)'])
y10_storage_10wt_60 = (Sample10_10_60_wt['G\' (Pa)'])

y1_storage_10wt = (Sample1_10wt['G\' (Pa)'])
y2_storage_10wt = (Sample2_10wt['G\' (Pa)'])
y3_storage_10wt = (Sample3_10wt['G\' (Pa)'])
y4_storage_10wt = (Sample4_10wt['G\' (Pa)'])
y5_storage_10wt = (Sample5_10wt['G\' (Pa)'])
y6_storage_10wt = (Sample6_10wt['G\' (Pa)'])
# y7_storage_10wt = (Sample7_10wt['G\' (Pa)'])
y8_storage_10wt = (Sample8_10wt['G\' (Pa)'])
y9_storage_10wt = (Sample9_10wt['G\' (Pa)'])
y10_storage_10wt = (Sample10_10wt['G\' (Pa)'])

y1_storage_12wt = (Sample1_12wt['G\' (Pa)'])
y2_storage_12wt = (Sample2_12wt['G\' (Pa)'])
y3_storage_12wt = (Sample3_12wt['G\' (Pa)'])
y4_storage_12wt = (Sample4_12wt['G\' (Pa)'])
y5_storage_12wt = (Sample5_12wt['G\' (Pa)'])
y6_storage_12wt = (Sample6_12wt['G\' (Pa)'])
y7_storage_12wt = (Sample7_12wt['G\' (Pa)'])
y8_storage_12wt = (Sample8_12wt['G\' (Pa)'])
y9_storage_12wt = (Sample9_12wt['G\' (Pa)'])
y10_storage_12wt = (Sample10_12wt['G\' (Pa)'])

#===========================================================================
#===========================================================================
#=========================================================================== Call loss moduli values into variables
y1_loss_5wt = (Sample1_5wt['G\" (Pa)'])
# y2_loss_5wt = (Sample2_5wt['G\" (Pa)'])
# y3_loss_5wt = (Sample3_5wt['G\" (Pa)'])
y4_loss_5wt = (Sample4_5wt['G\" (Pa)'])
y5_loss_5wt = (Sample5_5wt['G\" (Pa)'])
y6_loss_5wt = (Sample6_5wt['G\" (Pa)'])
y7_loss_5wt = (Sample7_5wt['G\" (Pa)'])
y8_loss_5wt = (Sample8_5wt['G\" (Pa)'])
y9_loss_5wt = (Sample9_5wt['G\" (Pa)'])
y10_loss_5wt = (Sample10_5wt['G\" (Pa)'])

y1_loss_7wt_60 = (Sample1_7_60_wt['G\" (Pa)'])
y2_loss_7wt_60 = (Sample2_7_60_wt['G\" (Pa)'])
y3_loss_7wt_60 = (Sample3_7_60_wt['G\" (Pa)'])
y4_loss_7wt_60 = (Sample4_7_60_wt['G\" (Pa)'])
y5_loss_7wt_60 = (Sample5_7_60_wt['G\" (Pa)'])
y6_loss_7wt_60 = (Sample6_7_60_wt['G\" (Pa)'])
y7_loss_7wt_60 = (Sample7_7_60_wt['G\" (Pa)'])
y8_loss_7wt_60 = (Sample8_7_60_wt['G\" (Pa)'])
y9_loss_7wt_60 = (Sample9_7_60_wt['G\" (Pa)'])
y10_loss_7wt_60 = (Sample10_7_60_wt['G\" (Pa)'])

y1_loss_7wt = (Sample1_7wt['G\" (Pa)'])
y2_loss_7wt = (Sample2_7wt['G\" (Pa)'])
y3_loss_7wt = (Sample3_7wt['G\" (Pa)'])
y4_loss_7wt = (Sample4_7wt['G\" (Pa)'])
y5_loss_7wt = (Sample5_7wt['G\" (Pa)'])
y6_loss_7wt = (Sample6_7wt['G\" (Pa)'])
y7_loss_7wt = (Sample7_7wt['G\" (Pa)'])
y8_loss_7wt = (Sample8_7wt['G\" (Pa)'])
y9_loss_7wt = (Sample9_7wt['G\" (Pa)'])
y10_loss_7wt = (Sample10_7wt['G\" (Pa)'])

y1_loss_10wt_60 = (Sample1_10_60_wt['G\" (Pa)'])
y2_loss_10wt_60 = (Sample2_10_60_wt['G\" (Pa)'])
y3_loss_10wt_60 = (Sample3_10_60_wt['G\" (Pa)'])
y4_loss_10wt_60 = (Sample4_10_60_wt['G\" (Pa)'])
y5_loss_10wt_60 = (Sample5_10_60_wt['G\" (Pa)'])
y6_loss_10wt_60 = (Sample6_10_60_wt['G\" (Pa)'])
y7_loss_10wt_60 = (Sample7_10_60_wt['G\" (Pa)'])
y8_loss_10wt_60 = (Sample8_10_60_wt['G\" (Pa)'])
y9_loss_10wt_60 = (Sample9_10_60_wt['G\" (Pa)'])
y10_loss_10wt_60 = (Sample10_10_60_wt['G\" (Pa)'])

y1_loss_10wt = (Sample1_10wt['G\" (Pa)'])
y2_loss_10wt = (Sample2_10wt['G\" (Pa)'])
y3_loss_10wt = (Sample3_10wt['G\" (Pa)'])
y4_loss_10wt = (Sample4_10wt['G\" (Pa)'])
y5_loss_10wt = (Sample5_10wt['G\" (Pa)'])
y6_loss_10wt = (Sample6_10wt['G\" (Pa)'])
# y7_loss_10wt = (Sample7_10wt['G\" (Pa)'])
y8_loss_10wt = (Sample8_10wt['G\" (Pa)'])
y9_loss_10wt = (Sample9_10wt['G\" (Pa)'])
y10_loss_10wt = (Sample10_10wt['G\" (Pa)'])

y1_loss_12wt = (Sample1_12wt['G\" (Pa)'])
y2_loss_12wt = (Sample2_12wt['G\" (Pa)'])
y3_loss_12wt = (Sample3_12wt['G\" (Pa)'])
y4_loss_12wt = (Sample4_12wt['G\" (Pa)'])
y5_loss_12wt = (Sample5_12wt['G\" (Pa)'])
y6_loss_12wt = (Sample6_12wt['G\" (Pa)'])
y7_loss_12wt = (Sample7_12wt['G\" (Pa)'])
y8_loss_12wt = (Sample8_12wt['G\" (Pa)'])
y9_loss_12wt = (Sample9_12wt['G\" (Pa)'])
y10_loss_12wt = (Sample10_12wt['G\" (Pa)'])

#===========================================================================
#===========================================================================
#=========================================================================== Call tan_delta values into variables
y1_td_5wt = (Sample1_5wt['tan_delta'])
# y2_td_5wt = (Sample2_5wt['tan_delta'])
# y3_td_5wt = (Sample3_5wt['tan_delta'])
y4_td_5wt = (Sample4_5wt['tan_delta'])
y5_td_5wt = (Sample5_5wt['tan_delta'])
y6_td_5wt = (Sample6_5wt['tan_delta'])
y7_td_5wt = (Sample7_5wt['tan_delta'])
y8_td_5wt = (Sample8_5wt['tan_delta'])
y9_td_5wt = (Sample9_5wt['tan_delta'])
y10_td_5wt = (Sample10_5wt['tan_delta'])

y1_td_7wt_60 = (Sample1_7_60_wt['tan_delta'])
y2_td_7wt_60 = (Sample2_7_60_wt['tan_delta'])
y3_td_7wt_60 = (Sample3_7_60_wt['tan_delta'])
y4_td_7wt_60 = (Sample4_7_60_wt['tan_delta'])
y5_td_7wt_60 = (Sample5_7_60_wt['tan_delta'])
y6_td_7wt_60 = (Sample6_7_60_wt['tan_delta'])
y7_td_7wt_60 = (Sample7_7_60_wt['tan_delta'])
y8_td_7wt_60 = (Sample8_7_60_wt['tan_delta'])
y9_td_7wt_60 = (Sample9_7_60_wt['tan_delta'])
y10_td_7wt_60 = (Sample10_7_60_wt['tan_delta'])

y1_td_7wt = (Sample1_7wt['tan_delta'])
y2_td_7wt = (Sample2_7wt['tan_delta'])
y3_td_7wt = (Sample3_7wt['tan_delta'])
y4_td_7wt = (Sample4_7wt['tan_delta'])
y5_td_7wt = (Sample5_7wt['tan_delta'])
y6_td_7wt = (Sample6_7wt['tan_delta'])
y7_td_7wt = (Sample7_7wt['tan_delta'])
y8_td_7wt = (Sample8_7wt['tan_delta'])
y9_td_7wt = (Sample9_7wt['tan_delta'])
y10_td_7wt = (Sample10_7wt['tan_delta'])

y1_td_10wt_60 = (Sample1_10_60_wt['tan_delta'])
y2_td_10wt_60 = (Sample2_10_60_wt['tan_delta'])
y3_td_10wt_60 = (Sample3_10_60_wt['tan_delta'])
y4_td_10wt_60 = (Sample4_10_60_wt['tan_delta'])
y5_td_10wt_60 = (Sample5_10_60_wt['tan_delta'])
y6_td_10wt_60 = (Sample6_10_60_wt['tan_delta'])
y7_td_10wt_60 = (Sample7_10_60_wt['tan_delta'])
y8_td_10wt_60 = (Sample8_10_60_wt['tan_delta'])
y9_td_10wt_60 = (Sample9_10_60_wt['tan_delta'])
y10_td_10wt_60 = (Sample10_10_60_wt['tan_delta'])

y1_td_10wt = (Sample1_10wt['tan_delta'])
y2_td_10wt = (Sample2_10wt['tan_delta'])
y3_td_10wt = (Sample3_10wt['tan_delta'])
y4_td_10wt = (Sample4_10wt['tan_delta'])
y5_td_10wt = (Sample5_10wt['tan_delta'])
y6_td_10wt = (Sample6_10wt['tan_delta'])
# y7_td_10wt = (Sample7_10wt['tan_delta'])
y8_td_10wt = (Sample8_10wt['tan_delta'])
y9_td_10wt = (Sample9_10wt['tan_delta'])
y10_td_10wt = (Sample10_10wt['tan_delta'])

y1_td_12wt = (Sample1_12wt['tan_delta'])
y2_td_12wt = (Sample2_12wt['tan_delta'])
y3_td_12wt = (Sample3_12wt['tan_delta'])
y4_td_12wt = (Sample4_12wt['tan_delta'])
y5_td_12wt = (Sample5_12wt['tan_delta'])
y6_td_12wt = (Sample6_12wt['tan_delta'])
y7_td_12wt = (Sample7_12wt['tan_delta'])
y8_td_12wt = (Sample8_12wt['tan_delta'])
y9_td_12wt = (Sample9_12wt['tan_delta'])
y10_td_12wt = (Sample10_12wt['tan_delta'])

#===========================================================================
#===========================================================================
#=========================================================================== Averaging values and calculating standard deviation for storage modulus
avgstorage5 = [stat.mean(i) for i in zip(y1_storage_5wt, #y2_storage_5wt, y3_storage_5wt,
                                    y4_storage_5wt, y5_storage_5wt, y6_storage_5wt, y7_storage_5wt, y8_storage_5wt, y9_storage_5wt, y10_storage_5wt)]
avgstorage7_60 = [stat.mean(i) for i in zip(y1_storage_7wt_60, y2_storage_7wt_60, y3_storage_7wt_60,
                                    y4_storage_7wt_60, y5_storage_7wt_60, y6_storage_7wt_60, y7_storage_7wt_60, y8_storage_7wt_60, y9_storage_7wt_60, y10_storage_7wt_60)]
avgstorage7 = [stat.mean(i) for i in zip(y1_storage_7wt, y2_storage_7wt, y3_storage_7wt,
                                    y4_storage_7wt, y5_storage_7wt, y6_storage_7wt, y7_storage_7wt, y8_storage_7wt, y9_storage_7wt, y10_storage_7wt)]
avgstorage10_60 = [stat.mean(i) for i in zip(y1_storage_10wt_60, y2_storage_10wt_60, y3_storage_10wt_60,
                                    y4_storage_10wt_60, y5_storage_10wt_60, y6_storage_10wt_60, y7_storage_10wt_60,
                                     y8_storage_10wt_60, y9_storage_10wt_60, y10_storage_10wt_60)]
avgstorage10 = [stat.mean(i) for i in zip(y1_storage_10wt, y2_storage_10wt, y3_storage_10wt,
                                    y4_storage_10wt, y5_storage_10wt, y6_storage_10wt, #y7_storage_10wt,
                                     y8_storage_10wt, y9_storage_10wt, y10_storage_10wt)]
avgstorage12 = [stat.mean(i) for i in zip(y1_storage_12wt, y2_storage_12wt, y3_storage_12wt,
                                    y4_storage_12wt, y5_storage_12wt, y6_storage_12wt, y7_storage_12wt, y8_storage_12wt, y9_storage_12wt, y10_storage_12wt)]

#=============== STD for storage modulus
SDstorage5 = [stat.stdev(i) for i in zip(y1_storage_5wt, #y2_storage_5wt, y3_storage_5wt,
                                    y4_storage_5wt, y5_storage_5wt, y6_storage_5wt, y7_storage_5wt, y8_storage_5wt, y9_storage_5wt, y10_storage_5wt)]
SDstorage7 = [stat.stdev(i) for i in zip(y1_storage_7wt, y2_storage_7wt, y3_storage_7wt,
                                    y4_storage_7wt, y5_storage_7wt, y6_storage_7wt, y7_storage_7wt, y8_storage_7wt, y9_storage_7wt, y10_storage_7wt)]
SDstorage7_60 = [stat.stdev(i) for i in zip(y1_storage_7wt_60, y2_storage_7wt_60, y3_storage_7wt_60,
                                    y4_storage_7wt_60, y5_storage_7wt_60, y6_storage_7wt_60, y7_storage_7wt_60, y8_storage_7wt_60, y9_storage_7wt_60, y10_storage_7wt_60)]
SDstorage10_60 = [stat.stdev(i) for i in zip(y1_storage_10wt_60, y2_storage_10wt_60, y3_storage_10wt_60,
                                    y4_storage_10wt_60, y5_storage_10wt_60, y6_storage_10wt_60, y7_storage_10wt_60,
                                     y8_storage_10wt_60, y9_storage_10wt_60, y10_storage_10wt_60)]
SDstorage10 = [stat.stdev(i) for i in zip(y1_storage_10wt, y2_storage_10wt, y3_storage_10wt,
                                    y4_storage_10wt, y5_storage_10wt, y6_storage_10wt, #y7_storage_10wt,
                                     y8_storage_10wt, y9_storage_10wt, y10_storage_10wt)]
SDstorage12 = [stat.stdev(i) for i in zip(y1_storage_12wt, y2_storage_12wt, y3_storage_12wt,
                                    y4_storage_12wt, y5_storage_12wt, y6_storage_12wt, y7_storage_12wt, y8_storage_12wt, y9_storage_12wt, y10_storage_12wt)]

#===========================================================================
#===========================================================================
#=========================================================================== Averaging values and calculating standard deviation for loss
avgloss5 = [stat.mean(i) for i in zip(y1_loss_5wt, #y2_loss_5wt, y3_loss_5wt,
                                     y4_loss_5wt, y5_loss_5wt, y6_loss_5wt, y7_loss_5wt, y8_loss_5wt, y9_loss_5wt, y10_loss_5wt)]
avgloss7_60 = [stat.mean(i) for i in zip(y1_loss_7wt_60, y2_loss_7wt_60, y3_loss_7wt_60,
                                     y4_loss_7wt_60, y5_loss_7wt_60, y6_loss_7wt_60, y7_loss_7wt_60, y8_loss_7wt_60, y9_loss_7wt_60, y10_loss_7wt_60)]
avgloss7 = [stat.mean(i) for i in zip(y1_loss_7wt, y2_loss_7wt, y3_loss_7wt,
                                     y4_loss_7wt, y5_loss_7wt, y6_loss_7wt, y7_loss_7wt, y8_loss_7wt, y9_loss_7wt, y10_loss_7wt)]
avgloss10_60 = [stat.mean(i) for i in zip(y1_loss_10wt_60, y2_loss_10wt_60, y3_loss_10wt_60,
                                      y4_loss_10wt_60, y5_loss_10wt_60, y6_loss_10wt_60, y7_loss_10wt_60,
                                      y8_loss_10wt_60, y9_loss_10wt_60, y10_loss_10wt_60)]
avgloss10 = [stat.mean(i) for i in zip(y1_loss_10wt, y2_loss_10wt, y3_loss_10wt,
                                      y4_loss_10wt, y5_loss_10wt, y6_loss_10wt, #y7_loss_10wt,
                                      y8_loss_10wt, y9_loss_10wt, y10_loss_10wt)]
avgloss12 = [stat.mean(i) for i in zip(y1_loss_12wt, y2_loss_12wt, y3_loss_12wt,
                                      y4_loss_12wt, y5_loss_12wt, y6_loss_12wt, y7_loss_12wt, y8_loss_12wt, y9_loss_12wt, y10_loss_12wt)]

# =============================== STD for storage modulus
SDloss5 = [stat.stdev(i) for i in zip(y1_loss_5wt, #y2_loss_5wt, y3_loss_5wt,
                                     y4_loss_5wt, y5_loss_5wt, y6_loss_5wt, y7_loss_5wt, y8_loss_5wt, y9_loss_5wt, y10_loss_5wt)]
SDloss7_60 = [stat.stdev(i) for i in zip(y1_loss_7wt_60, y2_loss_7wt_60, y3_loss_7wt_60,
                                     y4_loss_7wt_60, y5_loss_7wt_60, y6_loss_7wt_60, y7_loss_7wt_60, y8_loss_7wt_60, y9_loss_7wt_60, y10_loss_7wt_60)]
SDloss7 = [stat.stdev(i) for i in zip(y1_loss_7wt, y2_loss_7wt, y3_loss_7wt,
                                     y4_loss_7wt, y5_loss_7wt, y6_loss_7wt, y7_loss_7wt, y8_loss_7wt, y9_loss_7wt, y10_loss_7wt)]
SDloss10_60 = [stat.stdev(i) for i in zip(y1_loss_10wt_60, y2_loss_10wt_60, y3_loss_10wt_60,
                                      y4_loss_10wt_60, y5_loss_10wt_60, y6_loss_10wt_60, y7_loss_10wt_60,
                                      y8_loss_10wt_60, y9_loss_10wt_60, y10_loss_10wt_60)]
SDloss10 = [stat.stdev(i) for i in zip(y1_loss_10wt, y2_loss_10wt, y3_loss_10wt,
                                      y4_loss_10wt, y5_loss_10wt, y6_loss_10wt, #y7_loss_10wt,
                                      y8_loss_10wt, y9_loss_10wt, y10_loss_10wt)]
SDloss12 = [stat.stdev(i) for i in zip(y1_loss_12wt, y2_loss_12wt, y3_loss_12wt,
                                      y4_loss_12wt, y5_loss_12wt, y6_loss_12wt, y7_loss_12wt, y8_loss_12wt, y9_loss_12wt, y10_loss_12wt)]

#===========================================================================
#===========================================================================
#=========================================================================== Averaging values and calculating standard deviation for tan_delta
avgTD5 = [stat.mean(i) for i in zip(y1_td_5wt, #y2_td_5wt, y3_td_5wt,
                                    y4_td_5wt, y6_td_5wt, y7_td_5wt, y8_td_5wt, y9_td_5wt, y10_td_5wt)]
avgTD7_60 = [stat.mean(i) for i in zip(y1_td_7wt_60, y2_td_7wt_60, y3_td_7wt_60,
                                    y4_td_7wt_60, y5_td_7wt_60, y6_td_7wt_60, y7_td_7wt_60, y8_td_7wt_60, y9_td_7wt_60, y10_td_7wt_60)]
avgTD7 = [stat.mean(i) for i in zip(y1_td_7wt, y2_td_7wt, y3_td_7wt,
                                    y4_td_7wt, y5_td_7wt, y6_td_7wt, y7_td_7wt, y8_td_7wt, y9_td_7wt, y10_td_7wt)]
avgTD10_60 = [stat.mean(i) for i in zip(y1_td_10wt_60, y2_td_10wt_60, y3_td_10wt_60,
                                     y4_td_10wt_60, y5_td_10wt_60, y6_td_10wt_60,y7_td_10wt_60,
                                     y8_td_10wt_60, y9_td_10wt_60, y10_td_10wt_60)]
avgTD10 = [stat.mean(i) for i in zip(y1_td_10wt, y2_td_10wt, y3_td_10wt,
                                     y4_td_10wt, y5_td_10wt, y6_td_10wt, #y7_td_10wt,
                                     y8_td_10wt, y9_td_10wt, y10_td_10wt)]
avgTD12 = [stat.mean(i) for i in zip(y1_td_12wt, y2_td_12wt, y3_td_12wt,
                                     y4_td_12wt, y5_td_12wt, y6_td_12wt, y7_td_12wt, y8_td_12wt, y9_td_12wt, y10_td_12wt)]

#======================================= STD for TD
SDTD5 = [stat.stdev(i) for i in zip(y1_td_5wt, #y2_td_5wt, y3_td_5wt,
                                    y4_td_5wt, y6_td_5wt, y7_td_5wt, y8_td_5wt, y9_td_5wt, y10_td_5wt)]
SDTD7_60 = [stat.stdev(i) for i in zip(y1_td_7wt_60, y2_td_7wt_60, y3_td_7wt_60,
                                    y4_td_7wt_60, y5_td_7wt_60, y6_td_7wt_60, y7_td_7wt_60, y8_td_7wt_60, y9_td_7wt_60, y10_td_7wt_60)]
SDTD7 = [stat.stdev(i) for i in zip(y1_td_7wt, y2_td_7wt, y3_td_7wt,
                                    y4_td_7wt, y5_td_7wt, y6_td_7wt, y7_td_7wt, y8_td_7wt, y9_td_7wt, y10_td_7wt)]
SDTD10_60 = [stat.stdev(i) for i in zip(y1_td_10wt_60, y2_td_10wt_60, y3_td_10wt_60,
                                     y4_td_10wt_60, y5_td_10wt_60, y6_td_10wt_60,y7_td_10wt_60,
                                     y8_td_10wt_60, y9_td_10wt_60, y10_td_10wt_60)]
SDTD10 = [stat.stdev(i) for i in zip(y1_td_10wt, y2_td_10wt, y3_td_10wt,
                                     y4_td_10wt, y5_td_10wt, y6_td_10wt, #y7_td_10wt,
                                     y8_td_10wt, y9_td_10wt, y10_td_10wt)]
SDTD12 = [stat.stdev(i) for i in zip(y1_td_12wt, y2_td_12wt, y3_td_12wt,
                                     y4_td_12wt, y5_td_12wt, y6_td_12wt, y7_td_12wt, y8_td_12wt, y9_td_12wt, y10_td_12wt)]

#===========================================================================
#===========================================================================
#=========================================================================== Plot #1 - Storage Modulus
plt.figure(1, figsize=(15,8))
plt.scatter(x1_freq_5wt, avgstorage5, marker=".", s=100, edgecolors="purple",c="purple", label = "5 wt % 15-1")
SDstorage5_error = [SDstorage5]
plt.scatter(x2_freq_7wt, avgstorage7, marker=".", s=100, edgecolors="pink",c="pink", label = "7 wt % 15-1")
SDstorage7_error = [SDstorage7]
plt.scatter(x3_freq_10wt, avgstorage10, marker=".", s=100, edgecolors="orange",c="orange", label = "10 wt % 15-1")
SDstorage10_error = [SDstorage10]
plt.scatter(x3_freq_12wt, avgstorage12, marker=".", s=100, edgecolors="red",c="red", label = "12 wt % 15-1")
SDstorage12_error = [SDstorage12]
plt.scatter(x2_freq_7wt_60, avgstorage7_60, marker=".", s=100, edgecolors="green",c="green", label = "7 wt % 60-1")
SDstorage7_60_error = [SDstorage7_60]
plt.scatter(x3_freq_10wt_60, avgstorage10_60, marker=".", s=100, edgecolors="blue",c="blue", label = "10 wt % 60-1")
SDstorage10_60_error = [SDstorage10_60]
plt.legend(bbox_to_anchor =(1, 1), edgecolor='black', facecolor="white", framealpha=1)
_, AB1, _=plt.errorbar(x1_freq_5wt,avgstorage5, yerr=SDstorage5_error, fmt='o', ecolor="purple", color='purple', capsize=0, uplims=True)
_, AB2, _=plt.errorbar(x1_freq_7wt_60,avgstorage7_60, yerr=SDstorage7_60_error, fmt='o', ecolor="green", color='green', capsize=0, uplims=True)
_, AB3, _=plt.errorbar(x1_freq_7wt,avgstorage7, yerr=SDstorage7_error, fmt='o', ecolor="pink", color='pink', capsize=0, uplims=True)
_, AB4, _=plt.errorbar(x1_freq_10wt_60,avgstorage10_60, yerr=SDstorage10_60_error, fmt='o', ecolor="blue", color='blue', capsize=0, uplims=True)
_, AB5, _=plt.errorbar(x1_freq_10wt,avgstorage10, yerr=SDstorage10_error, fmt='o', ecolor="orange", color='orange', capsize=0, uplims=True)
_, AB6, _=plt.errorbar(x1_freq_12wt,avgstorage12, yerr=SDstorage12_error, fmt='o', ecolor="red", color='red',capsize=0, lolims=True)
AB1[0].set_marker('_')
AB1[0].set_markersize(10)
AB2[0].set_marker('_')
AB2[0].set_markersize(10)
AB3[0].set_marker('_')
AB3[0].set_markersize(10)
AB4[0].set_marker('_')
AB4[0].set_markersize(10)
AB5[0].set_marker('_')
AB5[0].set_markersize(10)
AB6[0].set_marker('_')
AB6[0].set_markersize(10)
#X and Y Axis Modification
plt.title("Storage Modulus Average", size=17)
plt.xlabel('Frequency (Hz)', size = 17)
plt.ylabel('G\' (Pa)', size=17)
plt.yscale("log")
plt.ylim(100, 100000)
plt.xscale("log")
plt.xlim(0.095, 10.75)
plt.grid(zorder=0, axis='x', which='minor', color=[0.85, 0.85, 0.85])
plt.axvline(zorder=0, linewidth=0.85, x=1, color='black', linestyle='-')
plt.tick_params(axis='x', labelsize=13)
plt.tick_params(axis='y', labelsize=13)
plt.savefig('Frequency Sweep - Storage Modulus.png', dpi=100)

#===========================================================================
#===========================================================================
#=========================================================================== Plot #2 - Storage Modulus
plt.figure(2, figsize=(15,8))
plt.scatter(x1_freq_5wt, avgloss5, marker=".", s=100, edgecolors="purple",c="purple", label = "5 wt % 15-1")
SDloss5_error = [SDloss5]
plt.scatter(x2_freq_7wt, avgloss7, marker=".", s=100, edgecolors="pink",c="pink", label = "7 wt % 15-1")
SDloss7_error = [SDloss7]
plt.scatter(x3_freq_10wt, avgloss10, marker=".", s=100, edgecolors="orange",c="orange", label = "10 wt % 15-1")
SDloss10_error = [SDloss10]
plt.scatter(x3_freq_12wt, avgloss12, marker=".", s=100, edgecolors="red",c="red", label = "12 wt % 15-1")
SDloss12_error = [SDloss12]
plt.scatter(x2_freq_7wt_60, avgloss7_60, marker=".", s=100, edgecolors="green",c="green", label = "7 wt % 60-1")
SDloss7_60_error = [SDloss7_60]
plt.scatter(x3_freq_10wt_60, avgloss10_60, marker=".", s=100, edgecolors="blue",c="blue", label = "10 wt % 60-1")
SDloss10_60_error = [SDloss10_60]
plt.legend(loc="upper right", bbox_to_anchor=(1, 1), edgecolor='black', facecolor="white", framealpha=1)
_, AB1, _=plt.errorbar(x1_freq_5wt,avgloss5, yerr=SDloss5_error, fmt='o', ecolor="purple", color='purple', capsize=0, uplims=True)
_, AB2, _=plt.errorbar(x1_freq_7wt_60,avgloss7_60, yerr=SDloss7_60_error, fmt='o', ecolor="green", color='green', capsize=0, uplims=True)
_, AB3, _=plt.errorbar(x1_freq_7wt,avgloss7, yerr=SDloss7_error, fmt='o', ecolor="pink", color='pink', capsize=0, uplims=True)
_, AB4, _=plt.errorbar(x1_freq_10wt_60,avgloss10_60, yerr=SDloss10_60_error, fmt='o', ecolor="blue", color='blue', capsize=0, uplims=True)
_, AB5, _=plt.errorbar(x1_freq_10wt,avgloss10, yerr=SDloss10_error, fmt='o', ecolor="orange", color='orange', capsize=0, uplims=True)
_, AB6, _=plt.errorbar(x1_freq_12wt,avgloss12, yerr=SDloss12_error, fmt='o', ecolor="red", color='red',capsize=0, lolims=True)
AB1[0].set_marker('_')
AB1[0].set_markersize(10)
AB2[0].set_marker('_')
AB2[0].set_markersize(10)
AB3[0].set_marker('_')
AB3[0].set_markersize(10)
AB4[0].set_marker('_')
AB4[0].set_markersize(10)
AB5[0].set_marker('_')
AB5[0].set_markersize(10)
AB6[0].set_marker('_')
AB6[0].set_markersize(10)
#X and Y Axis Modification
plt.title("Loss Modulus Average", size=17)
plt.xlabel('Frequency (Hz)', size = 17)
plt.ylabel('G\" (Pa)', size=17)
plt.yscale("log")
plt.ylim(10, 10000)
plt.xscale("log")
plt.xlim(0.095, 10.75)
plt.grid(zorder=0, axis='x', which='minor', color=[0.85, 0.85, 0.85])
plt.axvline(zorder=0, linewidth=0.85, x=1, color='black', linestyle='-')
plt.tick_params(axis='x', labelsize=13)
plt.tick_params(axis='y', labelsize=13)
plt.savefig('Frequency Sweep - Loss Modulus.png', dpi=100)

#===========================================================================
#===========================================================================
#=========================================================================== Plot #3 - Tan_delta
plt.figure(3, figsize=(15,8))
plt.scatter(x1_freq_5wt, avgTD5, marker=".", s=100, edgecolors="purple",c="purple", label = "5 wt % 15-1")
SDTD5_error = [SDTD5]
plt.scatter(x2_freq_7wt, avgTD7, marker=".", s=100, edgecolors="pink",c="pink", label = "7 wt % 15-1")
SDTD7_error = [SDTD7]
plt.scatter(x3_freq_10wt, avgTD10, marker=".", s=100, edgecolors="orange",c="orange", label = "10 wt % 15-1")
SDTD10_error = [SDTD10]
plt.scatter(x3_freq_12wt, avgTD12, marker=".", s=100, edgecolors="red",c="red", label = "12 wt % 15-1")
SDTD12_error = [SDTD12]
plt.scatter(x2_freq_7wt_60, avgTD7_60, marker=".", s=100, edgecolors="green",c="green", label = "7 wt % 60-1")
SDTD7_60_error = [SDTD7_60]
plt.scatter(x3_freq_10wt_60, avgTD10_60, marker=".", s=100, edgecolors="blue",c="blue", label = "10 wt % 60-1")
SDTD10_60_error = [SDTD10_60]
plt.legend(loc="upper right", bbox_to_anchor=(1, 1), edgecolor='black', facecolor="white", framealpha=1)
_, AB1, _=plt.errorbar(x1_freq_5wt,avgTD5, yerr=SDTD5_error, fmt='o', ecolor="purple", color='purple', capsize=0, uplims=True)
_, AB2, _=plt.errorbar(x1_freq_7wt_60,avgTD7_60, yerr=SDTD7_60_error, fmt='o', ecolor="green", color='green', capsize=0, uplims=True)
_, AB3, _=plt.errorbar(x1_freq_7wt,avgTD7, yerr=SDTD7_error, fmt='o', ecolor="pink", color='pink', capsize=0, uplims=True)
_, AB4, _=plt.errorbar(x1_freq_10wt_60,avgTD10_60, yerr=SDTD10_60_error, fmt='o', ecolor="blue", color='blue', capsize=0, uplims=True)
_, AB5, _=plt.errorbar(x1_freq_10wt,avgTD10, yerr=SDTD10_error, fmt='o', ecolor="orange", color='orange', capsize=0, uplims=True)
_, AB6, _=plt.errorbar(x1_freq_12wt,avgTD12, yerr=SDTD12_error, fmt='o', ecolor="red", color='red',capsize=0, lolims=True)
AB1[0].set_marker('_')
AB1[0].set_markersize(10)
AB2[0].set_marker('_')
AB2[0].set_markersize(10)
AB3[0].set_marker('_')
AB3[0].set_markersize(10)
AB4[0].set_marker('_')
AB4[0].set_markersize(10)
AB5[0].set_marker('_')
AB5[0].set_markersize(10)
AB6[0].set_marker('_')
AB6[0].set_markersize(10)
#X and Y Axis Modification
plt.title("Tan \u03B4 Average", size=17)
plt.xlabel('Frequency (Hz)', size = 17)
plt.ylabel("Tan \u03B4", size=17)
plt.ylim(0.0001, 0.5)
plt.xscale("log")
plt.xlim(0.095, 10.75)
plt.grid(zorder=0, axis='x', which='minor', color=[0.85, 0.85, 0.85])
plt.axvline(zorder=0, linewidth=0.85, x=1, color='black', linestyle='-')
plt.tick_params(axis='x', labelsize=13)
plt.tick_params(axis='y', labelsize=13)
plt.savefig('Frequency Sweep - Tan \u03B4 Average.png', dpi=100)